# Timoni plugin

This plugin adds completion for [Timoni](https://timoni.sh), a package manager for Kubernetes, powered by CUE and inspired by Helm.

To use it, add `timoni` to the plugins array in your zshrc file:

```zsh
plugins=(... timoni)
```
